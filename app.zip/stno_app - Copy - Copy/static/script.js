// Cyber Stego UI script — handles login, create account, dashboard UI and embed/extract actions

// --- Elements
const loginUsername = document.getElementById('login-username');
const loginPassword = document.getElementById('login-password');
const loginBtn = document.getElementById('loginBtn');
const openCreate = document.getElementById('openCreate');
const loginStatus = document.getElementById('loginStatus');

const createPage = document.getElementById('createPage');
const createSubmit = document.getElementById('createSubmit');
const createCancel = document.getElementById('createCancel');
const backToLogin = document.getElementById('backToLogin');
const createUserInput = document.getElementById('createUser');
const createPassInput = document.getElementById('createPass');

const infoBtn = document.getElementById('info-btn');
const infoBox = document.getElementById('info-box');
const logoutBtn = document.getElementById('logoutBtn');

const modeToggle = document.getElementById('modeToggle');
const fontSelect = document.getElementById('fontSelect');

const embedImageInput = document.getElementById('embedImage');
const embedMessageEl = document.getElementById('embedMessage');
const embedPasswordEl = document.getElementById('embedPassword');
const embedBtn = document.getElementById('embedBtn');
const embedCapacityEl = document.getElementById('embedCapacity');
const embedStatus = document.getElementById('embedStatus');

const extractImageInput = document.getElementById('extractImage');
const extractPasswordEl = document.getElementById('extractPassword');
const extractBtn = document.getElementById('extractBtn');
const decodedEl = document.getElementById('decoded');
const extractStatus = document.getElementById('extractStatus');
const saveDecodedBtn = document.getElementById('saveDecoded');

const loginSection = document.getElementById('login-section');
const dashboardSection = document.getElementById('dashboard-section');

let currentEmbedFile = null;
let currentExtractFile = null;

// --- local account demo (single local account)
if (!localStorage.getItem('cyber_user') || !localStorage.getItem('cyber_pass')) {
  localStorage.setItem('cyber_user', 'user');
  localStorage.setItem('cyber_pass', '1111');
}

// --- Create account modal handlers
if (openCreate) {
  openCreate.addEventListener('click', (e) => {
    e.preventDefault();
    createPage.classList.add('active');   // show modal with fade-in
  });
}

if (createCancel) {
  createCancel.addEventListener('click', () => {
    createPage.classList.remove('active'); // hide modal
  });
}

if (backToLogin) {
  backToLogin.addEventListener('click', (e) => {
    e.preventDefault();
    createPage.classList.remove('active'); // hide modal
  });
}

// Close modal if user clicks outside the card
if (createPage) {
  createPage.addEventListener('click', (e) => {
    if (e.target === createPage) {
      createPage.classList.remove('active');
    }
  });
}

// --- Create account submission
if (createSubmit) {
  createSubmit.addEventListener('click', () => {
    const username = createUserInput?.value.trim() || '';
    const password = createPassInput?.value.trim() || '';
    if (!username || !password) {
      alert('Please enter both username and password.');
      return;
    }

    // Save account locally
    localStorage.setItem('cyber_user', username);
    localStorage.setItem('cyber_pass', password);

    // Feedback to user
    alert('Account created locally. Please login.');

    // Hide modal
    createPage.classList.remove('active');

    // Pre-fill login form
    if (loginUsername) loginUsername.value = username;
    if (loginPassword) loginPassword.value = password;
    if (loginStatus) {
      loginStatus.textContent = 'Account created — please login.';
      loginStatus.style.color = 'var(--muted)';
    }
  });
}


// --- Login
if (loginBtn) {
  loginBtn.addEventListener('click', () => {
    const user = loginUsername?.value.trim() || '';
    const pass = loginPassword?.value.trim() || '';
    if (!user || !pass) {
      loginStatus.textContent = 'Please enter username and password.';
      loginStatus.style.color = 'orange';
      return;
    }
    const savedUser = localStorage.getItem('cyber_user');
    const savedPass = localStorage.getItem('cyber_pass');
    if (user === savedUser && pass === savedPass) {
      loginStatus.textContent = 'Login successful!';
      loginStatus.style.color = 'lightgreen';
      loginSection.style.display = 'none';
      dashboardSection.style.display = 'block';
      infoBtn.style.display = 'inline-block';
    } else {
      loginStatus.textContent = 'Incorrect username or password.';
      loginStatus.style.color = 'red';
    }
  });
}

// --- Logout
if (logoutBtn) {
  logoutBtn.addEventListener('click', () => {
    dashboardSection.style.display = 'none';
    loginSection.style.display = 'flex';
    loginPassword.value = '';
  });
}

// --- Mode toggle
if (modeToggle) {
  let night = true;
  modeToggle.addEventListener('click', () => {
    night = !night;
    modeToggle.textContent = night ? '🌙 Night Mode' : '☀️ Day Mode';
    document.body.style.background = night ? '' : '#ffffff';
  });
}

// --- Font selector for embed/decoded
if (fontSelect) {
  fontSelect.addEventListener('change', () => {
    const f = fontSelect.value || 'inherit';
    if (embedMessageEl) embedMessageEl.style.fontFamily = f;
    if (decodedEl) decodedEl.style.fontFamily = f;
  });
  window.addEventListener('load', () => {
    const f = fontSelect?.value || 'inherit';
    if (embedMessageEl) embedMessageEl.style.fontFamily = f;
    if (decodedEl) decodedEl.style.fontFamily = f;
  });
}

// --- Embed capacity
if (embedImageInput) embedImageInput.addEventListener('change', (e) => { currentEmbedFile = e.target.files?.[0] || null; calcCapacity(); });
if (embedMessageEl) embedMessageEl.addEventListener('input', calcCapacity);
function calcCapacity() {
  if (!embedCapacityEl) return;
  if (!currentEmbedFile) { embedCapacityEl.textContent = 'Capacity: —'; embedCapacityEl.style.color = ''; return; }
  const img = new Image();
  const url = URL.createObjectURL(currentEmbedFile);
  img.onload = function() {
    const pixels = img.width * img.height;
    const usableBytes = Math.floor((pixels - 36*8)/8);
    embedCapacityEl.textContent = `Capacity: ~${usableBytes} bytes (${img.width}×${img.height})`;
    if (embedMessageEl?.value.length > usableBytes) { embedCapacityEl.textContent += ' — message may be too long!'; embedCapacityEl.style.color = '#ff6c6c'; }
    else embedCapacityEl.style.color = '';
    URL.revokeObjectURL(url);
  };
  img.onerror = function(){ embedCapacityEl.textContent = 'Capacity: (failed to read image)'; URL.revokeObjectURL(url); };
  img.src = url;
}

// --- Embed POST
if (embedBtn) embedBtn.addEventListener('click', async () => {
  if (!currentEmbedFile) { alert('Upload an image first'); return; }
  const form = new FormData();
  form.append('image', currentEmbedFile);
  form.append('message', embedMessageEl?.value || '');
  form.append('password', embedPasswordEl?.value || '');
  embedStatus.textContent = 'Embedding...'; embedBtn.disabled = true;
  try {
    const res = await fetch('/embed', { method:'POST', body: form });
    if (!res.ok) {
      const err = await res.json().catch(()=>({error:'Server error'}));
      embedStatus.textContent = 'Error: '+ (err.error||'Server error'); embedBtn.disabled=false; return;
    }
    const blob = await res.blob();
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'stego-image.png';
    document.body.appendChild(a); a.click(); a.remove();
    embedStatus.textContent = '✅ Done — stego image downloaded.'; embedBtn.disabled=false;
  } catch (err) { embedStatus.textContent = 'Error: ' + err.message; embedBtn.disabled=false; }
});

// --- Extract POST
if (extractImageInput) extractImageInput.addEventListener('change', e => { currentExtractFile = e.target.files?.[0] || null; });
if (extractBtn) extractBtn.addEventListener('click', async () => {
  if (!currentExtractFile) { alert('Upload a stego-image first'); return; }
  const form = new FormData();
  form.append('image', currentExtractFile);
  form.append('password', extractPasswordEl?.value || '');
  extractStatus.textContent = 'Extracting...'; extractBtn.disabled=true; decodedEl.textContent='';
  try {
    const res = await fetch('/extract', { method:'POST', body: form });
    const data = await res.json();
    if (!res.ok) { extractStatus.textContent='Error: '+(data.error||'Server error'); decodedEl.textContent='(no message)'; saveDecodedBtn.style.display='none'; extractBtn.disabled=false; return; }
    extractStatus.textContent='✅ Success.'; decodedEl.textContent=data.message||'(empty message)'; decodedEl.style.fontFamily = fontSelect?.value||'inherit';
    saveDecodedBtn.style.display='inline-block';
  } catch (err) { extractStatus.textContent='Error: '+err.message; decodedEl.textContent='(no message)'; saveDecodedBtn.style.display='none'; }
  finally { extractBtn.disabled=false; }
});

// --- Save decoded
if (saveDecodedBtn) saveDecodedBtn.addEventListener('click', () => {
  const text = decodedEl?.textContent || '';
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([text], {type:'text/plain'}));
  a.download='decoded-message.txt';
  document.body.appendChild(a); a.click(); a.remove();
});

// --- System info
if (infoBtn) infoBtn.addEventListener('click', async () => {
  infoBtn.disabled=true; infoBtn.textContent='Fetching system info...';
  try {
    const res = await fetch('/system_info');
    if (!res.ok) throw new Error('No system info');
    const data = await res.json();
    infoBox.innerHTML = `<div class="card" style="padding:12px; background:var(--panel); border-radius:10px;">
      <h3 style="margin:0 0 8px; color:var(--neon1)">🔧 Backend Info</h3>
      <div class="muted"><b>Framework:</b> ${data.Framework}</div>
      <div class="muted"><b>Python:</b> ${data["Python Version"]} (${data.Platform})</div>
      <div class="muted"><b>Pillow:</b> ${data["Libraries Used"].Pillow}</div>
      <div class="muted"><b>NumPy:</b> ${data["Libraries Used"].NumPy}</div>
      <div class="muted" style="margin-top:8px;">${data.Purpose}</div>
      <div style="text-align:right; margin-top:10px;"><button id="close-info" class="btn ghost">Close</button></div>
    </div>`;
    infoBox.style.display='block';
    document.getElementById('close-info').addEventListener('click', ()=> infoBox.style.display='none');
  } catch(err){
    infoBox.innerHTML='<div class="card" style="padding:12px;"><div style="color:#ff7b7b">❌ Unable to fetch system info.</div></div>';
    infoBox.style.display='block';
  } finally { infoBtn.disabled=false; infoBtn.textContent='Show System Info'; }
});
