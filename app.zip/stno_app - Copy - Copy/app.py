from flask import Flask, request, render_template, send_file, jsonify
from io import BytesIO
from PIL import Image
import numpy as np
from Crypto.Cipher import AES
from Crypto.Protocol.KDF import PBKDF2
from Crypto.Random import get_random_bytes
import struct
import platform
import sys

app = Flask(__name__, static_folder='static', template_folder='templates')

ALLOWED_EXT = {'png', 'jpg', 'jpeg'}

PBKDF2_ITER = 100000
SALT_LEN = 16
IV_LEN = 16
KEY_LEN = 32
HEADER_LEN_BYTES = 4 + SALT_LEN + IV_LEN


@app.route("/")
def index():
    return render_template("index.html")


# ------------------ Helper Functions ------------------ #

def allowed_file(filename: str):
    return filename and '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXT


def bytes_to_bitlist(b: bytes):
    bits = []
    for byte in b:
        for i in range(7, -1, -1):
            bits.append((byte >> i) & 1)
    return bits


def bitlist_to_bytes(bits):
    out = bytearray()
    for i in range(0, len(bits), 8):
        byte = 0
        for j in range(8):
            if i + j < len(bits):
                byte = (byte << 1) | bits[i + j]
            else:
                byte = (byte << 1)
        out.append(byte)
    return bytes(out)


def embed_bits_in_image(img, bits):
    if img.mode not in ("RGB", "RGBA"):
        img = img.convert("RGBA")

    arr = np.array(img)
    flat_blue = arr[..., 2].flatten()

    if len(bits) > len(flat_blue):
        raise ValueError("Image too small for message.")

    flat_blue[:len(bits)] = (flat_blue[:len(bits)] & 0xFE) | np.array(bits, dtype=np.uint8)
    arr[..., 2] = flat_blue.reshape(arr[..., 2].shape)

    return Image.fromarray(arr)


def extract_bits_from_image(img, num_bits):
    if img.mode not in ("RGB", "RGBA"):
        img = img.convert("RGBA")

    arr = np.array(img)
    flat_blue = arr[..., 2].flatten()
    return [int(flat_blue[i] & 1) for i in range(num_bits)]


def derive_key(password: str, salt: bytes) -> bytes:
    return PBKDF2(password.encode("utf-8"), salt, dkLen=KEY_LEN, count=PBKDF2_ITER)


# ------------------ Embed Route ------------------ #

@app.route('/embed', methods=['POST'])
def embed_route():
    file = request.files.get('image')
    message = request.form.get('message', '')
    password = request.form.get('password', '')

    if not allowed_file(file.filename):
        return jsonify({"error": "Invalid file format."})

    img = Image.open(file).convert("RGBA")

    msg_bytes = message.encode("utf-8")

    # Encryption
    if password:
        salt = get_random_bytes(SALT_LEN)
        key = derive_key(password, salt)
        iv = get_random_bytes(IV_LEN)

        cipher = AES.new(key, AES.MODE_CBC, iv)

        pad_len = AES.block_size - (len(msg_bytes) % AES.block_size)
        padded = msg_bytes + bytes([pad_len]) * pad_len
        payload = cipher.encrypt(padded)

        header = struct.pack(">I", len(payload)) + salt + iv

    else:
        payload = msg_bytes
        header = struct.pack(">I", len(payload)) + b"\x00" * SALT_LEN + b"\x00" * IV_LEN

    full_bytes = header + payload
    bits = bytes_to_bitlist(full_bytes)

    stego = embed_bits_in_image(img, bits)
    bio = BytesIO()
    stego.save(bio, format="PNG")
    bio.seek(0)

    return send_file(bio, mimetype="image/png", as_attachment=True, download_name="stego.png")


# ------------------ Extract Route ------------------ #

@app.route('/extract', methods=['POST'])
def extract_route():
    file = request.files.get('image')
    password = request.form.get('password', "")

    if not allowed_file(file.filename):
        return jsonify({"error": "Invalid file format."})

    img = Image.open(file).convert("RGBA")

    header_bits = extract_bits_from_image(img, HEADER_LEN_BYTES * 8)
    header_bytes = bitlist_to_bytes(header_bits)

    payload_len = struct.unpack(">I", header_bytes[:4])[0]
    salt = header_bytes[4:4 + SALT_LEN]
    iv = header_bytes[4 + SALT_LEN:4 + SALT_LEN + IV_LEN]

    payload_bits = extract_bits_from_image(img, (HEADER_LEN_BYTES + payload_len) * 8)[HEADER_LEN_BYTES * 8:]
    payload_bytes = bitlist_to_bytes(payload_bits)

    # If encrypted
    if password and salt != b"\x00" * SALT_LEN:
        try:
            key = derive_key(password, salt)
            cipher = AES.new(key, AES.MODE_CBC, iv)
            decrypted_padded = cipher.decrypt(payload_bytes)

            pad_len = decrypted_padded[-1]
            decrypted = decrypted_padded[:-pad_len]

            return jsonify({"message": decrypted.decode("utf-8")})

        except:
            return jsonify({"error": "Wrong password or corrupt image."})

    else:
        try:
            return jsonify({"message": payload_bytes.decode("utf-8")})
        except:
            return jsonify({"error": "Invalid message."})

@app.route('/system_info')
def system_info():
    import sys
    import platform
    import PIL
    import numpy

    return jsonify({
        "Framework": "Flask",
        "Python Version": sys.version.split()[0],
        "Platform": platform.system(),
        "Libraries Used": {
            "Pillow": PIL.__version__,
            "NumPy": numpy.__version__
        },
        "Purpose": "Provides backend system information for Cyber Stego project."
    })

if __name__ == "__main__":
    app.run(debug=True)
